import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';

import '../constants/app_colors.dart';
import '../widgets/round_raised_button.dart';
import '../screens/auth/login_screen.dart';
import '../screens/auth/register_screen.dart';
import 'package:firebase_core/firebase_core.dart';

class OnBoardScreen extends StatefulWidget {
  static const routeName = '/on-board';



  @override

  _OnBoardScreenState createState() => _OnBoardScreenState();

}

class _OnBoardScreenState extends State<OnBoardScreen> {
  final List<String> images = [
    'assets/images/carousal1.jpg',
    'assets/images/carousal2.jpg',
    'assets/images/carousal1.jpg',
    'assets/images/carousal2.jpg',
  ];
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage('assets/images/carousal1.jpg'),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Container(
              child: CarouselSlider(
                options: CarouselOptions(
                    autoPlay: true,
                    autoPlayInterval: Duration(seconds: 5),
                    aspectRatio: 16 / 5,
                    viewportFraction: 0.9,
                    onPageChanged: (index, reason) {
                      setState(() {
                        _currentIndex = index;
                      });
                    }),
                items: images
                    .map((e) => Builder(
                          builder: (context) => Container(
                            padding: EdgeInsets.symmetric(horizontal: 10),
                            child: Column(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text(
                                    'Meet edisiuS, your mental health companion; your friend',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 18),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(2.0),
                                  child: Text(
                                    'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut tempus ac arcu eget interdum. ',

                                    textAlign: TextAlign.center,
                                  ),
                                )
                              ],
                            ),
                          ),
                        ))
                    .toList(),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [0, 1, 2, 3].map((index) {
                return Container(
                  width: 8.0,
                  height: 8.0,
                  margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 2.0),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _currentIndex == index
                        ? Color.fromRGBO(0, 0, 0, 0.9)
                        : Color.fromRGBO(0, 0, 0, 0.4),
                  ),
                );
              }).toList(),
            ),
            SizedBox(height: 30),
            RoundRaisedButton(
              text: 'Sign up',
              textColor: Colors.white,
              bgColor: AppColors.primaryColor,
              onTap: () =>
                  Navigator.pushNamed(context, RegisterScreen.routeName),
            ),
            RoundRaisedButton(
              text: 'Log in',
              textColor: AppColors.primaryColor,
              bgColor: Colors.white,
              borderColor: AppColors.primaryColor,
              onTap: () => Navigator.pushNamed(context, LogInScreen.routeName),
            ),
            Align(
              alignment: Alignment.topLeft,
              child: SizedBox(
                height: 60,
                child: Container(
                  child: Image.asset('assets/logos/logo-word.png'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
