class Blog {
  String title;
  String category;
  String imgUrl;
  int likes;

  Blog({this.title, this.category, this.imgUrl, this.likes = 0});
}
