class BlogVideo {
  String videoUrl;
  String thumbnailUrl;

  BlogVideo({this.videoUrl, this.thumbnailUrl});
}