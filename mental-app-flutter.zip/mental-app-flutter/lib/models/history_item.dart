class HistoryItem {
  DateTime dateTime;
  String description;

  HistoryItem({this.dateTime, this.description});
}