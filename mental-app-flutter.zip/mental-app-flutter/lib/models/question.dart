class Question {
  String question;
  List<String> answers = [];

  Question(this.question, this.answers);
}