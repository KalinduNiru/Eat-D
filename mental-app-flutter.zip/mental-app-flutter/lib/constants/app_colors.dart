import 'package:flutter/material.dart';

class AppColors {
  static const Color primaryColor = Color.fromRGBO(88, 45, 137, 1);
  static const Color secondaryColor = Color.fromRGBO(55, 196, 207, 1);
  static const Color iconColor = Colors.black;
}